export enum TipoTransporteOferta {
  CEGONHA = 'CEGONHA',

  RAMPA = 'RAMPA',

  GUINCHO = 'GUINCHO',
}

export enum Solicitações {
  Solicitações = 'Aguardando proposta',

  Atendida = 'Atendida',

  Cancelada = 'Cancelada',
}
