export enum TipoCarga {
  MOTO = 'MOTO',

  CARRO = 'CARRO',

  CAMINHAO = 'CAMINHAO',
}
