export enum TipoCategoria {
  CEGONHA = 'CEGONHA',

  GUINCHO = 'GUINCHO',

  REBOQUE = 'REBOQUE',

  OUTRO = 'OUTRO',
}
