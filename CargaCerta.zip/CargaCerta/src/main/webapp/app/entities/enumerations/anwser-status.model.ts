export enum AnwserStatus {
  SIM = 'SIM',

  NAO = 'NAO',
}
