export enum WhatsStatus {
  OPEN = 'OPEN',

  CLOSED = 'CLOSED',

  CANCELED = 'CANCELED',
}
