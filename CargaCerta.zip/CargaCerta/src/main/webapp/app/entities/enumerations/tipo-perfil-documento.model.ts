export enum TipoPerfilDocumento {
  ANTT = 'ANTT',

  CNH = 'CNH',

  RG = 'RG',

  CNPJ = 'CNPJ',

  OUTROS = 'OUTROS',
}
