export enum TipoOferta {
  CARGA = 'CARGA',
  VAGAS = 'VAGAS',
}
