package com.infocargas.freteapp.domain.enumeration;

/**
 * The TipoPerfilDocumento enumeration.
 */
public enum TipoPerfilDocumento {
    ANTT,
    CNH,
    RG,
    CNPJ,
    OUTROS,
}
