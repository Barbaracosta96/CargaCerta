package com.infocargas.freteapp.domain.enumeration;

/**
 * The StatusOferta enumeration.
 */
public enum StatusOferta {
    AGUARDANDO_PROPOSTA,
    ATENDIDA_INFOCARGAS,
    ATENDIDA,
    CANCELED,
}
