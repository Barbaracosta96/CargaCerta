package com.infocargas.freteapp.domain.enumeration;

public enum GoogleErrors {
    ERROR_STATUS_400, ERROR_NULL_ROUTE, ERRORS_RETURN_NULL
}
