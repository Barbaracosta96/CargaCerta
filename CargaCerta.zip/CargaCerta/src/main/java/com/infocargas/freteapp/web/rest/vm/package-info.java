/**
 * View Models used by Spring MVC REST controllers.
 */
package com.infocargas.freteapp.web.rest.vm;
