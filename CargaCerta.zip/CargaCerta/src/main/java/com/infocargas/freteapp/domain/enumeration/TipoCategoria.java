package com.infocargas.freteapp.domain.enumeration;

/**
 * The TipoCategoria enumeration.
 */
public enum TipoCategoria {
    CEGONHA,
    GUINCHO,
    REBOQUE,
    OUTRO,
}
