package com.infocargas.freteapp.service.dto;

public class ClickatellMessageDTO {}
