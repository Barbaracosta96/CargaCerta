package com.infocargas.freteapp.response.facebook;

public class FacebookSimpleResponse {}
