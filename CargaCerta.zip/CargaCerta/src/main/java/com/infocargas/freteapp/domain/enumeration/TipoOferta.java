package com.infocargas.freteapp.domain.enumeration;

/**
 * The TipoOferta enumeration.
 */
public enum TipoOferta {
    CARGA,
    VAGAS,
}
