package com.infocargas.freteapp.domain.enumeration;

/**
 * The TipoConta enumeration.
 */
public enum TipoConta {
    MOTORISTA,
    TRANSPORTADORA,
    EMBARCADOR,
}
