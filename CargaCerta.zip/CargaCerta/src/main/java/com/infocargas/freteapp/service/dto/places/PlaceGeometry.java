package com.infocargas.freteapp.service.dto.places;

public class PlaceGeometry {

    private PlaceLocation location;

    public PlaceLocation getLocation() {
        return location;
    }

    public void setLocation(PlaceLocation location) {
        this.location = location;
    }
}
