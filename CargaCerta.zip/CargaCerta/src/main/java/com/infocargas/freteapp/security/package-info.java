/**
 * Spring Security configuration.
 */
package com.infocargas.freteapp.security;
