/**
 * Service layer beans.
 */
package com.infocargas.freteapp.service;
