/**
 * Data Transfer Objects.
 */
package com.infocargas.freteapp.service.dto;
