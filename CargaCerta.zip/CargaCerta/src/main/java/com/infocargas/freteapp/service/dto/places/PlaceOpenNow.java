package com.infocargas.freteapp.service.dto.places;

public class PlaceOpenNow {

    private Boolean open_now;

    public Boolean getOpen_now() {
        return open_now;
    }

    public void setOpen_now(Boolean open_now) {
        this.open_now = open_now;
    }
}
