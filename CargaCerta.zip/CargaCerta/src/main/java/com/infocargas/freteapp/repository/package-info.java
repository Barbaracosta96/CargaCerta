/**
 * Spring Data JPA repositories.
 */
package com.infocargas.freteapp.repository;
