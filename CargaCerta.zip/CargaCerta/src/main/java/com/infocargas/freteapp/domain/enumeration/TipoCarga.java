package com.infocargas.freteapp.domain.enumeration;

/**
 * The TipoCarga enumeration.
 */
public enum TipoCarga {
    MOTO,
    CARRO,
    CAMINHAO,
}
