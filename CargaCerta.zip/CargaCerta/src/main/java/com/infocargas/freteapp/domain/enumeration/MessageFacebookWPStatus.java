package com.infocargas.freteapp.domain.enumeration;

public enum MessageFacebookWPStatus {
    DELIVERY,
    READ,
    SENT,
    NOTFOUND,
}
