/**
 * Spring Framework configuration files.
 */
package com.infocargas.freteapp.config;
