package com.infocargas.freteapp.domain.enumeration;

/**
 * The StatusSolicitacao enumeration.
 */
public enum StatusSolicitacao {
    AGUARDANDORESPOSTA,
    AGUARDANDO,
    RECUSADO,
    ACEITOU,
    CANCELOU,
}
