/**
 * JPA domain objects.
 */
package com.infocargas.freteapp.domain;
