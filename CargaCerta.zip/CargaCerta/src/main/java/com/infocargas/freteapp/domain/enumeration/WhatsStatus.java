package com.infocargas.freteapp.domain.enumeration;

/**
 * The WhatsStatus enumeration.
 */
public enum WhatsStatus {
    OPEN,
    CLOSED,
    CANCELED,
}
