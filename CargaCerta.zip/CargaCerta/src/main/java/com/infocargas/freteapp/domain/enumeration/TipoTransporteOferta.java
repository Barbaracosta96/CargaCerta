package com.infocargas.freteapp.domain.enumeration;

/**
 * The TipoTransporteOferta enumeration.
 */
public enum TipoTransporteOferta {
    CEGONHA,
    RAMPA,
    GUINCHO,
}
