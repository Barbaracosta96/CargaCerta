package com.infocargas.freteapp.domain.enumeration;

/**
 * The AnwserStatus enumeration.
 */
public enum AnwserStatus {
    SIM,
    NAO,
}
